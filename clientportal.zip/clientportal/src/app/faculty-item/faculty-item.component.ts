import { Component, OnInit,Input} from '@angular/core';

@Component({
  selector: 'app-faculty-item',
  templateUrl: './faculty-item.component.html',
  styleUrls: ['./faculty-item.component.css']
})
export class FacultyItemComponent implements OnInit {
@Input() name:string;
@Input() degree:string;
@Input() link:string;
  constructor() { }

  ngOnInit() {
  }

}
