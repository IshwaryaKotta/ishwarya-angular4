import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-owl-item-carousel',
  templateUrl: './owl-item-carousel.component.html',
  styleUrls: ['./owl-item-carousel.component.css']
})
export class OwlItemCarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
