import { Component, OnInit,HostListener,Inject} from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import {WindowRefService} from '../window-ref.service';
@Component({
  selector: 'app-header-component',
  templateUrl: './header-component.component.html',
  styleUrls: ['./header-component.component.css']
})
export class HeaderComponentComponent implements OnInit {

  public navIsFixed: boolean = false;

  constructor(@Inject(DOCUMENT) private document: Document,@Inject(WindowRefService) private window) { }

  ngOnInit() {
  }
  @HostListener("window:scroll",[])
  onWindowScroll(){
    let number = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
    if (number > 100) {
      this.navIsFixed = true;
    } else if (this.navIsFixed && number < 10) {
      this.navIsFixed = false;
    }
  }

}
