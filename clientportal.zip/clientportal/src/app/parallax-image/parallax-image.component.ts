import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parallax-image',
  templateUrl: './parallax-image.component.html',
  styleUrls: ['./parallax-image.component.css']
})
export class ParallaxImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
