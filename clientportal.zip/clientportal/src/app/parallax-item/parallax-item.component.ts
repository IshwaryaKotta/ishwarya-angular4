import { Component, OnInit,Input } from '@angular/core';


@Component({
  selector: 'app-parallax-item',
  templateUrl: './parallax-item.component.html',
  styleUrls: ['./parallax-item.component.css']
})
export class ParallaxItemComponent implements OnInit {
@Input() srclink:string;
@Input() title:string;
@Input() desc:string;
@Input() color:string;
  constructor() { }

  ngOnInit() {
  }

}
