import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faculty-items-all',
  templateUrl: './faculty-items-all.component.html',
  styleUrls: ['./faculty-items-all.component.css']
})
export class FacultyItemsAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
