import { Component, OnInit,Input} from '@angular/core';

@Component({
  selector: 'app-owl-item',
  templateUrl: './owl-item.component.html',
  styleUrls: ['./owl-item.component.css']
})
export class OwlItemComponent implements OnInit {
@Input() imglink:string;
@Input() price:string;
@Input() title:string;
@Input() desc:string;
  constructor() { }

  ngOnInit() {
  }

}
