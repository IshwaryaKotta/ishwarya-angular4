import { Component, OnInit} from '@angular/core';
import {OpenImageDirective} from './open-image.directive';
@Component({
  selector: 'app-photo-gallery',
  templateUrl: './photo-gallery.component.html',
  styleUrls: ['./photo-gallery.component.css']
})
export class PhotoGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
