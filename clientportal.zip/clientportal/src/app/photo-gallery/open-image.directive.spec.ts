import { OpenImageDirective } from './open-image.directive';

describe('OpenImageDirective', () => {
  it('should create an instance', () => {
    const directive = new OpenImageDirective();
    expect(directive).toBeTruthy();
  });
});
