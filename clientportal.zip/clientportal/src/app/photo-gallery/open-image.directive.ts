import { Directive,ElementRef,HostListener,Renderer2 } from '@angular/core';

@Directive({
  selector: '[appOpenImage]'
})
export class OpenImageDirective {

  public openImage = false;
  constructor(
    private el:ElementRef ,
    private r:Renderer2
  ) { 
  }

  @HostListener('click',['$event.target'])
  onclick()
  {
    this.r.setStyle('img','transform','scale(1.2)');
  }
}
