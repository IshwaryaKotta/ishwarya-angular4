import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-last-footer',
  templateUrl: './last-footer.component.html',
  styleUrls: ['./last-footer.component.css']
})
export class LastFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
