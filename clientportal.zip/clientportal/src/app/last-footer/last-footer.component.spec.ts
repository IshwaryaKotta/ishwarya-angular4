import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastFooterComponent } from './last-footer.component';

describe('LastFooterComponent', () => {
  let component: LastFooterComponent;
  let fixture: ComponentFixture<LastFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
