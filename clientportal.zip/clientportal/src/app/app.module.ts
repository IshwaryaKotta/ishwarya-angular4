import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { SocialIconsComponent } from './social-icons/social-icons.component';
import { TitleComponent } from './title/title.component';
import { HeaderComponentComponent } from './header-component/header-component.component';
import { CarouselComponent } from './carousel/carousel.component';
import { AccordionLeftComponent } from './accordion-left/accordion-left.component';
import { AccordionModule } from 'ngx-accordion';
import { FormsModule } from '@angular/forms';
import {ScrollPanelModule} from 'primeng/scrollpanel';
import {PanelModule} from 'primeng/panel';
import { PanelsComponent } from './panels/panels.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TileComponent } from './tile/tile.component';
import { OwlItemComponent } from './owl-item/owl-item.component';
import { OwlItemCarouselComponent } from './owl-item-carousel/owl-item-carousel.component';
import { CounterTileComponent } from './counter-tile/counter-tile.component';
import { ParallaxImageComponent } from './parallax-image/parallax-image.component';
import { ParallaxItemComponent } from './parallax-item/parallax-item.component';
import { SiteAnnouncementsComponent } from './site-announcements/site-announcements.component';
import { FacultyItemComponent } from './faculty-item/faculty-item.component';
import { FacultyItemsAllComponent } from './faculty-items-all/faculty-items-all.component';
import { PhotoGalleryComponent } from './photo-gallery/photo-gallery.component';
import { CompanyCarouselComponent } from './company-carousel/company-carousel.component';
import { FooterComponent } from './footer/footer.component';
import { LastFooterComponent } from './last-footer/last-footer.component';
import { WindowRefService } from './window-ref.service';
import { OpenImageDirective } from './photo-gallery/open-image.directive';
import { AppRoutingModule } from './/app-routing.module';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { CourseComponent } from './course/course.component';
@NgModule({
  declarations: [
    AppComponent,
    SocialIconsComponent,
    TitleComponent,
    HeaderComponentComponent,
    CarouselComponent,
    AccordionLeftComponent,
    PanelsComponent,
    TileComponent,
    OwlItemComponent,
    OwlItemCarouselComponent,
    CounterTileComponent,
    ParallaxImageComponent,
    ParallaxItemComponent,
    SiteAnnouncementsComponent,
    FacultyItemComponent,
    FacultyItemsAllComponent,
    PhotoGalleryComponent,
    CompanyCarouselComponent,
    FooterComponent,
    LastFooterComponent,
    OpenImageDirective,
    AboutComponent,
    HomeComponent,
    CourseComponent
  ],
  imports: [
    BrowserModule,AccordionModule,FormsModule,ScrollPanelModule,PanelModule,BrowserAnimationsModule, AppRoutingModule
  ],
  providers: [WindowRefService],
  bootstrap: [AppComponent]
})
export class AppModule { }
