import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-carousel',
  templateUrl: './company-carousel.component.html',
  styleUrls: ['./company-carousel.component.css']
})
export class CompanyCarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
