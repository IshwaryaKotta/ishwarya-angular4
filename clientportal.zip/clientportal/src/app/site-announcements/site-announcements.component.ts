import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-announcements',
  templateUrl: './site-announcements.component.html',
  styleUrls: ['./site-announcements.component.css']
})
export class SiteAnnouncementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
