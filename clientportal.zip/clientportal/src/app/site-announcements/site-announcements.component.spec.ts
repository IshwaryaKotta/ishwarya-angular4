import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteAnnouncementsComponent } from './site-announcements.component';

describe('SiteAnnouncementsComponent', () => {
  let component: SiteAnnouncementsComponent;
  let fixture: ComponentFixture<SiteAnnouncementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteAnnouncementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteAnnouncementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
