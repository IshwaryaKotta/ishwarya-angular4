import { Component,HostListener,Inject } from '@angular/core';
import {WindowRefService} from './window-ref.service';
import {DOCUMENT} from '@angular/platform-browser';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  showOutlet = true;
  public HideTopButton:string ="none";
  constructor(@Inject(DOCUMENT) private document: Document,@Inject(WindowRefService) private window)
  {

  }
  @HostListener("window:scroll",[])
  onWindowScroll(){
    let number = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
    if (number > 500) {
      this.HideTopButton ="block";
    }
    else
    {
      this.HideTopButton ="none";
    }
  }
  onActivate(event : any) {
    this.showOutlet = false;
  }
  
  onDeactivate(event : any) {
    this.showOutlet = true;
  }
}
