import { Component, OnInit,Input} from '@angular/core';

@Component({
  selector: 'app-counter-tile',
  templateUrl: './counter-tile.component.html',
  styleUrls: ['./counter-tile.component.css']
})
export class CounterTileComponent implements OnInit {
  @Input() count:string;
  @Input() desc:string;
  constructor() { }

  ngOnInit() {
  }

}
