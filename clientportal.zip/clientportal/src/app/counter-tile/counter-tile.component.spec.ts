import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CounterTileComponent } from './counter-tile.component';

describe('CounterTileComponent', () => {
  let component: CounterTileComponent;
  let fixture: ComponentFixture<CounterTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CounterTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CounterTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
