import { Component, OnInit } from '@angular/core';
import {PanelModule} from 'primeng/panel';
@Component({
  selector: 'app-panels',
  templateUrl: './panels.component.html',
  styleUrls: ['./panels.component.css']
})
export class PanelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
