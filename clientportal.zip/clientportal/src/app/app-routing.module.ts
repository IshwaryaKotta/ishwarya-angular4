import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { AboutComponent } from './about/about.component';
import { PhotoGalleryComponent } from './photo-gallery/photo-gallery.component';
import { FacultyItemsAllComponent } from './faculty-items-all/faculty-items-all.component';
import { ParallaxImageComponent } from './parallax-image/parallax-image.component';
import { OwlItemCarouselComponent } from './owl-item-carousel/owl-item-carousel.component';
import { HomeComponent } from './home/home.component';
import { CourseComponent } from './course/course.component';
const routes:Routes = [
  {path:'home',component:HomeComponent},
  { path:'about', component:AboutComponent},
  { path:'gallery', component:PhotoGalleryComponent},
  { path:'pages', component:ParallaxImageComponent},
  { path:'contact', component:FacultyItemsAllComponent},
  { path:'course/:id', component:CourseComponent}
];
@NgModule({
  imports: [
   RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
 
})
export class AppRoutingModule { }
