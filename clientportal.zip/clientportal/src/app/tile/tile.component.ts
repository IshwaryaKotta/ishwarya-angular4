import { Component, OnInit ,Input} from '@angular/core';

@Component({
selector: 'app-tile',
templateUrl: './tile.component.html',
styleUrls: ['./tile.component.css']
})
export class TileComponent {
@Input() colorName:string;
@Input() title:string;
@Input() desc:string;
@Input() link:string;
constructor() { 
}
}
