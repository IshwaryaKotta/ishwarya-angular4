import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccordionLeftComponent } from './accordion-left.component';

describe('AccordionLeftComponent', () => {
  let component: AccordionLeftComponent;
  let fixture: ComponentFixture<AccordionLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccordionLeftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccordionLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
