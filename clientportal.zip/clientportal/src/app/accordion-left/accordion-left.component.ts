import { Component, OnInit } from '@angular/core';
import {AccordionModule} from 'ngx-accordion';
import {FormsModule} from '@angular/forms';
import {PanelModule} from 'primeng/panel';

const now = new Date();

@Component({
  selector: 'app-accordion-left',
  templateUrl: './accordion-left.component.html',
  styleUrls: ['./accordion-left.component.css']
})
export class AccordionLeftComponent implements OnInit {
status:boolean =false;
  constructor() { }

  ngOnInit() {
  }
toggleactive()
{
  this.status = !this.status;
}
}